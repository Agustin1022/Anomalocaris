<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Projeto</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<!-- Devido a falta de sistema de autenticação, para acessar o conteúdo das páginas de Professores, Administradores e Alunos
ainda é necessário alterar o caminho para a pasta de ADM, PROFESSOR ou ALUNO e para o arquivo abaixo para PROF_menu.php, ADM_menu.php ou ALUNO_menu.php -->

    <div id="menu"><?php include 'ALUNO/ALUNO_menu.php'; ?></div>
    <div id="conteudo"><?php include $conteudo; ?></div>
    <div id="rodape"><?php include 'rodape.php' ?></div>

    <script src="script.js"></script>
</body>
</html>