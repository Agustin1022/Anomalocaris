<?php
$link=mysqli_connect("localhost","root","")or die("Erro no mysql");
mysqli_select_db($link,"sanquim")or die("Erro na base de dados");
// Conferir o nome da base de dados
?>