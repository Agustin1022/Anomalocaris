function toggleDropdown() {
  const menu = document.getElementById('dropdownMenu');
  menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
}

let currentButton = null;

const professores = {
  "Engenharia": "Ana Célia",
  "Algoritmo": "Maromo",
  "Programação": "PC",
  "Comunicação": "Sandra",
  "Matemática": "Márcio",
  "Arquitetura": "Thales"
};

const emails = {
  "Engenharia": "ana.celia@exemplo.com",
  "Algoritmo": "maromo@exemplo.com",
  "Programação": "pc@exemplo.com",
  "Comunicação": "sandra@exemplo.com",
  "Matemática": "marcio@exemplo.com",
  "Arquitetura": "thales@exemplo.com"
};

const planos = {
  "Engenharia": "Prova - 30/06",
  "Algoritmo": "(Nenhum plano)",
  "Programação": "Atividade extra em 01/07",
  "Comunicação": "(Nenhum plano)",
  "Matemática": "(Nenhum plano)",
  "Arquitetura": "(Nenhum plano)"
};

const turma = [
  "Agustín Nardi",
  "Gustavo Costa Bazan",
  "Kauã Fontes Cândido",
  "Léo Leme de Oliveira",
  "Thiago Oliveira Cabral",
  "Vitor Miguel Mestriner"
];

function toggleModal(button, curso) {
  const modal = document.getElementById("modalBox");

  // Se clicou no mesmo botão, fecha
  if (currentButton === button) {
    closeModal();
    return;
  }

  currentButton = button;

  // Atualiza conteúdo do modal
  document.getElementById("professorInfo").innerHTML = `
  <strong>Professor:</strong> ${professores[curso] || "(Desconhecido)"}
  <span class="divider">|</span>
  <strong>Email:</strong> ${emails[curso] || "sem@email.com"}`;
  document.getElementById("planoInfo").textContent = planos[curso] || "(Nenhum plano)";

  const turmaLista = document.getElementById("turmaLista");
  turmaLista.innerHTML = "";
  turma.forEach(aluno => {
    const li = document.createElement("li");
    li.textContent = aluno;
    turmaLista.appendChild(li);
  });

  // Posiciona o modal perto do botão clicado
  modal.style.display = "block";
}

function closeModal() {
  const modal = document.getElementById("modalBox");
  modal.style.display = "none";
  currentButton = null;
}

function toggleDropdown() {
  const menu = document.getElementById('dropdownMenu');
  menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
}

function toggleLista(el) {
  const lista = el.nextElementSibling;
  lista.style.display = lista.style.display === 'block' ? 'none' : 'block';
}

function toggleDropdown() {
  const menu = document.getElementById('dropdownMenu');
  if (menu) {
    menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
  }
}
