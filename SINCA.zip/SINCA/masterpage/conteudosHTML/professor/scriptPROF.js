
function toggleDropdown() {
  const menu = document.getElementById('dropdownMenu');
  if (menu) {
    menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
  }
}
