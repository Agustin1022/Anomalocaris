<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="images/sanquinpnglogo.ico" type="image/x-icon">
    <title>SINCA</title>
</head>
<body>

<!-- Devido a falta de sistema de autenticação, para acessar o conteúdo das páginas de Professores, Administradores e Alunos
ainda é necessário alterar o caminho para a pasta de ADM, PROFESSOR ou ALUNO e para o arquivo abaixo para PROF_index.html, ADM_index.html ou ALUNO_index.html -->

    <?php
        $conteudo = 'ADM/ADM_index.php';
        include 'master.php';
    ?>
    
</body>
</html>