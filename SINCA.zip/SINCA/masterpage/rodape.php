<div id="rodape">
    <p>Todos os direitos reservados &copy; 2025</p>
    <p>Desenvolvido por Gustavo Bazan, Thiago Cabral, Vitor Mestriner, Agustín Nardi, Kauã Cândido</p>
</div>