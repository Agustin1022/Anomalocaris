<?php
include "conecta.php"; // Conectar ao banco de dados
$id=$_REQUEST['id'];//pegar os dados do formulário
$nome_curso=$_REQUEST['nome_curso'];
$periodo=$_REQUEST['periodo'];
$carga_horaria=$_REQUEST['carga_horaria'];
$modalidade=$_REQUEST['modalidade'];
$curso=$_REQUEST['status'];
$inserir = "INSERT INTO matricula (id, nome_curso, periodo, carga_horaria, modalidade, status) 
VALUES ('$id', '$nome_curso', '$periodo', '$carga_horaria', '$modalidade', '$status')";//inserir os dados na tabela matricula
$resultado = mysqli_query($link, $inserir) or die("Erro no insert");
header("Location: index.php"); // Redirecionar para a página principal
?>