<?php
include "conecta.php"; // Conectar ao banco de dados
$id=$_REQUEST['id'];//pegar os dados do formulário
$nome_disciplina=$_REQUEST['nome_disciplina'];
$carga_horaria=$_REQUEST['carga_horaria'];
$status=$_REQUEST['status'];
$inserir = "INSERT INTO matricula (id, nome_disciplina, carga_horaria, status) 
VALUES ('$id', '$nome_disciplina', '$carga_horaria', '$status')";//inserir os dados na tabela matricula
$resultado = mysqli_query($link, $inserir) or die("Erro no insert");
header("Location: index.php"); // Redirecionar para a página principal
?>