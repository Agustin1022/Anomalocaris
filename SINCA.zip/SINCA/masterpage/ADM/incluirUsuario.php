<?php
include "conecta.php"; // Conectar ao banco de dados
$id=$_REQUEST['id'];//pegar os dados do formulário
$usuario=$_REQUEST['usuario'];
$senha=$_REQUEST['senha'];
$nivel=$_REQUEST['nivel'];
$status=$_REQUEST['status'];
$inserir = "INSERT INTO matricula (id, usuario, senha, nivel, status) 
VALUES ('$id', '$usuario', '$senha', '$nivel', '$status')";//inserir os dados na tabela matricula
$resultado = mysqli_query($link, $inserir) or die("Erro no insert");
header("Location: index.php"); // Redirecionar para a página principal
?>