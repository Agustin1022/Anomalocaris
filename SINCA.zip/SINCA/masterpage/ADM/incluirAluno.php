<?php
include "conecta.php"; // Conectar ao banco de dados
$id=$_REQUEST['id'];//pegar os dados do formulário
$ra=$_REQUEST['ra'];
$nome=$_REQUEST['nome'];
$curso=$_REQUEST['curso'];
$inserir = "INSERT INTO matricula (id, RA, nome, curso) 
VALUES ('$id', '$ra', '$nome', '$curso')";//inserir os dados na tabela matricula
$resultado = mysqli_query($link, $inserir) or die("Erro no insert");
header("Location: index.php"); // Redirecionar para a página principal
?>