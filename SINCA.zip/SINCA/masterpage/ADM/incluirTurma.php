<?php
include "conecta.php"; // Conectar ao banco de dados
$id=$_REQUEST['id'];//pegar os dados do formulário
$nome_turma=$_REQUEST['nome_turma'];
$curso=$_REQUEST['curso'];
$local=$_REQUEST['local'];
$periodo=$_REQUEST['periodo'];
$status=$_REQUEST['status'];
$inserir = "INSERT INTO matricula (id, nome_turma, curso, local, periodo, status) 
VALUES ('$id', '$nome_turma', '$curso', '$local', '$periodo', '$status')";//inserir os dados na tabela matricula
$resultado = mysqli_query($link, $inserir) or die("Erro no insert");
header("Location: index.php"); // Redirecionar para a página principal
?>